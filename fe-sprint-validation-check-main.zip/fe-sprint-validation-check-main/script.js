let elInputUsername = document.querySelector('#username')

let elInputPassword = document.querySelector('#password')
let elInputPasswordretype = document.querySelector('#password-retype')

let elFailureMessage = document.querySelector('.failure-message')
let elSuccessMessage = document.querySelector('.success-message')
let elMismatchmessage = document.querySelector('.mismatch-message')

///////////////////////////////     아이디    //////////////////////////////////////////////
//아이디 입력창 (elInputUsername)에 글자를 키보드로 입력할때(onkeyup)
elInputUsername.onkeyup = function () {
 

  if (isMoreThan4Length(elInputUsername.value)) {
    //성공 메시지가 보여야 함
    elSuccessMessage.classList.remove('hide')

    //실패 메시지가 가려져야 함
    elFailureMessage.classList.add('hide')
  } else {
    //성공 메시지가 가려져야 함
    elSuccessMessage.classList.add('hide') 
    
    //실패 메시지가 보여야 함
    elFailureMessage.classList.remove('hide')
  }
}
function isMoreThan4Length(value) {
  return value.length >= 4
}// 글자 수가 4개 이상이면
///////////////////////////////     비밀번호    //////////////////////////////////////////////

//비밀번호 입력시 비밀빈호확인 값과 일치하지 않으면 메세지 출력
elInputPasswordretype.onkeyup = function () {
  if ( isMatch(elInputPassword.value, elInputPasswordretype.value)) {
    elMismatchmessage.classList.add('hide')
  } 
  else {
    elMismatchmessage.classList.remove('hide')
  }
}

// 비밀번호 값과 확인값이 일치하는지 판별
function isMatch (password1, password2) {
  if (password1 === password2) {
    return true;
  }
  else {
    return false;
  }
}